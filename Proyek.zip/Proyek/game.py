import heapq

def heuristic(state):

    distance = 0
    for i in range(3):
        for j in range(3):
            if state[i][j] != 0:
                goal_i, goal_j = divmod(state[i][j] - 1, 3)
                distance += abs(i - goal_i) + abs(j - goal_j)
    return distance


def generate_moves(state):
    moves = []
    for i in range(3):
        for j in range(3):
            if state[i][j] == 0:
                if i > 0:
                    new_state = [row[:] for row in state]
                    new_state[i][j], new_state[i - 1][j] = new_state[i - 1][j], new_state[i][j]
                    moves.append(new_state)
                if i < 2:
                    new_state = [row[:] for row in state]
                    new_state[i][j], new_state[i + 1][j] = new_state[i + 1][j], new_state[i][j]
                    moves.append(new_state)
                if j > 0:
                    new_state = [row[:] for row in state]
                    new_state[i][j], new_state[i][j - 1] = new_state[i][j - 1], new_state[i][j]
                    moves.append(new_state)
                if j < 2:
                    new_state = [row[:] for row in state]
                    new_state[i][j], new_state[i][j + 1] = new_state[i][j + 1], new_state[i][j]
                    moves.append(new_state)
    return moves

def solve_puzzle(initial_state):
    open_list = []
    closed_list = set()
    heapq.heappush(open_list, (0, initial_state, 0, None))


    while open_list:
        _, state, cost, parent = heapq.heappop(open_list)
        closed_list.add(tuple(map(tuple, state)))
        if state == [[1, 2, 3], [4, 5, 6], [7, 8, 0]]:
            path = []
            while parent:
                path.append(parent[1])
                state, parent = parent[0], parent[2]
            return path[::-1]

        moves = generate_moves(state)
        for move in moves:
            if tuple(map(tuple, move)) not in closed_list:
                move_cost = cost + 1
                priority = move_cost + heuristic(move)
                heapq.heappush(open_list, (priority, move, move_cost, (state, move, parent)))

    return None

# Game initialization
def initialize_game():
    initial_state = []
    print("Enter the initial state (use 0 for the blank space):")
    for _ in range(3):
        row = list(map(int, input().split()))
        initial_state.append(row)
    return initial_state

def print_state(state):
    for row in state:
        print(row)

def print_moves(path):
    print("Solution path:")
    for i, move in enumerate(path):
        print(f"Move {i + 1}:")
        print_state(move)
        print()

# Game execution
def play_game():
    print("Solving the puzzle...")
    solution_path = solve_puzzle([[1, 2, 3], [4, 0, 6], [7, 5, 8]])
    if solution_path:
        print_moves(solution_path)
    else:
        print("No solution found.")

# Start the game
play_game()
